<?php
// Programmer Name: 93
// Purpose: Close database connection

if (isset($connection)) {
    mysqli_close($connection);
}
?>
