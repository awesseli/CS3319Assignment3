-- Part 1 SQL Updates
-- Show tables BEFORE we update

USE assign2db;

SELECT * FROM customer;

-- Change "Super Man" to "Wonder Woman"
UPDATE customer
SET firstname = 'Wonder', lastname = 'Woman'
WHERE firstname = 'Super' AND lastname = 'Man';

-- Change every product that Sideshow purchased was a quantity of 5

SELECT * FROM purchases;

UPDATE purchases
SET quantity = 5 WHERE cusID = (
SELECT cusID FROM customer WHERE firstname = 'Sideshow');

-- Make every customer of Regis come from the city of Boston

SELECT * FROM customer;

UPDATE customer
SET city = 'Boston' WHERE agentID = (
SELECT agentID FROM agent WHERE firstname = 'Regis');

-- Prove all commands worked

SELECT * FROM customer;
SELECT * FROM purchases;

-- PART 2 SQL Inserts
-- Inserting an agent
INSERT INTO agent VALUES ('67','Walter','White','Albuquerque', 99);

-- Inserting Product
INSERT INTO product VALUES ('27', 'Baseball' , 5.00, 100);

-- Inserting a customer
INSERT INTO customer VALUES ('46', 'Jesse', 'Pinkman', 'Albuquerque', '5023042301', '67');

-- Inserting a Purchase
INSERT INTO purchases VALUES ('46', '27', 10); 

-- Prove inserts worked
SELECT * FROM agent;
SELECT * FROM customer;
SELECT * FROM purchases;
SELECT * FROM product;

-- PART 3 SQL Queries
-- Query 1

SELECT description FROM product;

-- Query 2

SELECT DISTINCT city FROM customer;

-- Query 3

SELECT * FROM agent ORDER BY city ASC;

-- Query 4

SELECT firstname, lastname FROM customer WHERE city = 'Springfield';

-- Query 5

SELECT c.lastname FROM customer c JOIN agent a ON a.agentID = c.agentID
WHERE a.firstname = 'Hugh';

-- Query 6

SELECT description FROM product WHERE description LIKE '%pad%';

-- Query 7

SELECT c.firstname, c.lastname, p.description, pu.quantity
FROM purchases pu
JOIN customer c ON c.cusID = pu.cusID
JOIN product p ON p.prodID = pu.prodID;

-- Query 8

SELECT SUM(pu.quantity) AS `Homer's Total Purchases` FROM purchases pu
JOIN customer c ON c.cusID = pu.cusID WHERE c.firstname = 'Homer';

-- Query 9

SELECT c.firstname, c.lastname, SUM(pu.quantity) AS total_purchased
FROM purchases pu
JOIN customer c ON c.cusID = pu.cusID
GROUP BY c.cusID, c.firstname, c.lastname;

-- Query 10

SELECT p.description, p.quantityonhand FROM product p
LEFT JOIN purchases pu ON pu.prodID = p.prodID
-- Looking for NULL values here, hence left join
WHERE pu.prodID IS NULL;

-- Query 11
-- Using these AS statements because firstname and lastname are in both agents and customers
SELECT a.firstname AS agent_firstname, a.lastname AS agent_lastname,
c.firstname AS customer_firstname, c.lastname AS customer_lastname, c.city
FROM customer c
JOIN agent a on a.agentID = c.agentID WHERE a.city = c.city;

-- Query 12

SELECT (SELECT SUM(pu.quantity) FROM purchases pu
JOIN product p2 ON p2.prodID = pu.prodID WHERE p2.description = 'Knee Pads')
AS `Total Knee Pads Purchased`, 
(SELECT quantityonhand FROM product WHERE description = 'Knee Pads')
AS `Knee Pads In Stock`;

-- Query 13

SELECT p.prodID, p.description, COUNT(DISTINCT pu.cusID) AS customers_purchased
FROM purchases pu
JOIN product p ON p.prodID = pu.prodID GROUP BY p.prodID, p.description
HAVING COUNT(DISTINCT pu.cusID) >= 2;

-- Query 14

SELECT t.firstname, t.lastname, CONCAT('$', FORMAT(t.total_commission, 2))
AS `Highest Commission Payment` FROM
(SELECT a.agentID, a.firstname, a.lastname,

-- Total sales made by each agent, then convert to commission

 SUM(pu.quantity * p.cost) * (a.commission / 100)
AS total_commission FROM agent a

-- Join everything together
LEFT JOIN customer c ON c.agentID = a.agentID
LEFT JOIN purchases pu ON pu.cusID = c.cusID
LEFT JOIN product p on p.prodID = pu.prodID
GROUP BY a.agentID, a.firstname, a.lastname, a.commission) AS t

-- Only show the top earner
ORDER BY t.total_commission DESC LIMIT 1; 

-- Query 15
-- I want to look at our top spending customers, or who has spent the most money.

SELECT c.firstname, c.lastname, CONCAT('$', FORMAT(SUM(pu.quantity * p.cost), 2)) AS total_spent
FROM purchases pu
JOIN customer c ON c.cusID = pu.cusID
JOIN product p ON p.prodID = pu.prodID
GROUP BY c.cusID, c.firstname, c.lastname
ORDER BY SUM(pu.quantity *p.cost) DESC;

-- PART 4 SQL Views/Deletes

CREATE VIEW v_customer_purchases_detail AS
SELECT c.firstname AS customer_firstname, c.lastname as customer_lastname,
p.description AS product_description, pu.quantity AS quantity, p.cost AS product_price,
(pu.quantity * p.cost) AS total
FROM purchases pu 
JOIN customer c ON c.cusID = pu.cusID
JOIN product p ON p.prodID = pu.prodID;

-- Prove it works
SELECT * FROM v_customer_purchases_detail;

-- Show rows > $100
SELECT * FROM v_customer_purchases_detail WHERE total > 100;

-- Show everything in the product table
SELECT * FROM product;

-- Delete product with ID '44'
DELETE FROM product WHERE prodID ='44';

-- Prove this worked
SELECT * FROM product;

-- Show agent data
SELECT * FROM agent;

-- Delete Ottawa agents
DELETE FROM agent WHERE city = 'Ottawa';

-- Prove this worked
SELECT * FROM agent;

-- Attempt to delete agents from Bedrock
DELETE FROM agent WHERE city = 'Bedrock';

-- The Bedrock agent row were not deleted because customer rows reference them still.
